from django.shortcuts import render, redirect
from .models import Contact

def home(request):
    contacts= Contact.objects.all()
    return render(request, 'home.html', {'contacts': contacts})

def add_contact(request):
    if request.method == "POST":
        Contact.objects.create(
            first_name=request.POST['first_name'],
            last_name=request.POST['last_name'],
            address=request.POST['address'],
            email=request.POST['email'],
            phone=request.POST['phone']
        )
        return redirect('home')
        
    return render(request, 'form.html')

def delete_contact(request, id):
    contact= Contact.objects.get(id=id)
    contact.delete()
    return redirect('home')

def edit_contact(request, id):
    contact= Contact.objects.get(id=id)

    if request.method=="POST":
        contact.first_name=request.POST['first_name']
        contact.last_name=request.POST['last_name']
        contact.address=request.POST['address']
        contact.email=request.POST['email'] 
        contact.phone=request.POST['phone']

        contact.save()
        return redirect('home')
    return render(request, 'form.html', {'contact': contact})